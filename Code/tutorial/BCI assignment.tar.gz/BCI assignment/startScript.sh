#!/bin/bash
echo starting script
cd Code
python controlScript.py
