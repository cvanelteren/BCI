import subprocess, os
subprocess.call(os.path.realpath('../../../debug_quickstart.bat'),\
creationflags=subprocess.CREATE_NEW_CONSOLE)
