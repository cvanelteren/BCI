#!/usr/bin/python
#rewritten script in python from the matlab adaptation
#  Author:  Casper van Elteren

import bufhelp, pickle, classification, preproc, time
import numpy as np
from h5py import File, special_dtype
from pylab import *

# connect to buffer
ftc, hdr = bufhelp.connect()

# storage for the data
dataDir = '../../Data/'
file = dataDir + 'test_subject.hdf5'

# p300 occurs up to 500 ms after stimulus
# taking 100 ms more than expectation
trlen_ms = 600
run = True

print("Waiting for start event.")
while run:
    e = bufhelp.waitforevent('start',1000, 0)

    # print(':',type(e))
    # print(e)
    if e is not None:
        # print(e[0], e[1])
        # print('Found event')calibration
        if e.value == "calibration":
            print("Calibration phase")
            # catch events
            data, events, stopevents = bufhelp.gatherdata(\
                                        ['target','stimulus'], \
                                        trlen_ms, ("calibration", "end"), \
                                        milliseconds=True, verbose = False)

            # convert to arrays and save to disk
            data = np.array(data)
            dt = special_dtype(vlen=bytes)
            ev = np.array([(event.type, event.value) for event in events])
            # print(data.shape, ev.shape)
            with File(file,'w') as f:
                # f.create_dataset('targets', data = tmp)
                f.create_dataset('data', data = data)
                f.create_dataset('events', data = ev, dtype = dt)
                # f.create_dataset()

            print("End calibration phase")

        elif e.value == "train":
            print("Training classifier")
            # linear detrend, filter, average across epochs
            # to be on the save side i picked a normal range;
            # there is some evidence that p300 is within the theta / alpha band.
            # Here i choose a wide band pass that would be able to catch it
            # and supress high frequency noise.
            filterBand = [0, 60]
            data = preproc.stdPreproc(data, filterBand, hdr)
            erpTarget, erpStimulus, cat, labels =  preproc.binarizeData(data, events)

            # print(labels, cat.shape)
            model = classification.LogReg(cat, labels)

            bufhelp.sendEvent("training","done")

        elif e.value =="test":
            print("Feedback phase")
            keep = True
            while keep:
                data, events, stopevents = bufhelp.gatherdata(["stimulus"],\
                trlen_ms,[("run","end"),\
                ('test', 'end')], \
                milliseconds=True, verbose = False)
                if stopevents.type == 'test' and stopevents.value == 'end':
                    keep = False
                else:
                    filterBand = [0, 60]
                    tic = time.time()
                    # linear detrend, filter, average across epochs
                    data = preproc.stdPreproc(data, filterBand, hdr)
                    # average over time
                    mdata = np.mean(data, 1)
                    # compute the probability of each event with respect to
                    # the binary classes
                    pred = model.predict_proba(mdata)
                    # obtain the row, i.e. event, of the max probability
                    # with respect to the target class
                    idx = np.argmax(pred, int(labels[0]))[0]
                    pred = events[idx].value
                    print('prediction', pred)
                    # print('>', time.time() - tic)
                    # print('prediction', pred)
                    # print('prediction',  preds)

                    bufhelp.sendEvent("classifier.prediction", pred)

        elif e.value =="exit":
            run = False
        # print(e.value)
        print("Waiting for start event.")
