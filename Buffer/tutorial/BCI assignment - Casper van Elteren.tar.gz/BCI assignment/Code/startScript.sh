#!/bin/bash
echo starting script
cd bufferInterface/
python controlScript.py
